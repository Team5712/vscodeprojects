/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017-2018 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

#include "Robot.hpp"
using namespace std;

void Robot::RobotInit()
{

	int l_ids[3] = {1, 2, 3};
	int r_ids[3] = {4, 5, 6};
	drive = new GMDrive(l_ids, r_ids);

	joystick_l = new frc::Joystick(0);
	joystick_r = new frc::Joystick(1);
	joystick_aux = new frc::Joystick(3);
	joystick_button_board = new frc::Joystick(2);

	drive->SetSafetyEnabled(false);
	drive->initPID();

	compressor = new frc::Compressor(0);
	gyro = new AHRS(SPI::Port::kMXP, AHRS::kRawData, 200);
	gyro_correction = new GyroCorrection(gyro);
	climber = new Climber();
	elevator = new Elevator();
	intake = new Intake();
	passover = new Passover();

	vision_tracking = new Tracking();
	drive->resetEncoders();
	cout << "Robot init complete " << endl;
}

void Robot::handleDriverInput()
{

	// VISION TAPE
	if (joystick_l->GetRawButton(driver_buttons["middle"]))
	{
		cout << "left middle" << endl;

		vision_tracking->setPipeline(0);

		// CARGO
	}
	else if (joystick_r->GetRawButton(driver_buttons["middle"]))
	{
		// cout << "right middle" << endl;
		// vision_tracking->setPipeline(1);
	}
	else if (joystick_l->GetRawButton(driver_buttons["left"]))
	{
		vector<float> setpoint = vision_tracking->getTurnAdjustmentPercents(1, 0);

		adjust_l = setpoint[0];
		adjust_r = setpoint[1];
	}
	else if (joystick_l->GetRawButton(driver_buttons["right"]))
	{

		vector<float> setpoint = vision_tracking->getTurnAdjustmentPercents(1, 1);

		adjust_l = setpoint[0];
		adjust_r = setpoint[1];
	}
	else if (joystick_r->GetRawButton(driver_buttons["left"]))
	{

		vector<float> setpoint = vision_tracking->getTurnAdjustmentPercents(0, 0);

		adjust_l = setpoint[0];
		adjust_r = setpoint[1];
	}
	else if (joystick_r->GetRawButton(driver_buttons["right"]))
	{
		cout << "right button pressed" << endl;
		//drive straight
		//drive->TankDrive(-0.5, -0.5, true);
		//drive->driveSetInches(24,24);

		// vector<float> setpoint = vision_tracking->getTurnAdjustmentPercents(0, 1);

		// adjust_l = setpoint[0];
		// adjust_r = setpoint[1];
	}
	else if (joystick_l->GetRawButton(driver_buttons["trigger"]) && joystick_r->GetRawButton(driver_buttons["trigger"]))
	{
		drive->updateShifter(true);
	}
	else
	{
		// drive->resetEncoders();
		drive->updateShifter(false);
	}
}

void Robot::handleAuxiliaryInput()
{

	// // CLIMB LOW: : Green switch backwards && climb switch is to the right
	// if (joystick_button_board->GetRawButton(14) && joystick_button_board->GetRawButton(11) && climb_state == CLIMB_STATES::READY)
	// {
	// 	cout << "climb second " << endl;
	// 	climb_state = CLIMB_STATES::LOWERING_SECOND;
	// }

	// // CLIMB HIGH: Green switch backwards && climb switch is to the left
	// if (joystick_button_board->GetRawButton(14) && !joystick_button_board->GetRawButton(11) && climb_state == CLIMB_STATES::READY)
	// {
	// 	cout << "climb third " << endl;
	// 	climb_state = CLIMB_STATES::LOWERING_THIRD;
	// }

	// RESET CLIMBER
	// if (joystick_button_board->GetRawButton(13))
	// {
	// 	climb_state = CLIMB_STATES::RESET;
	// }

	if (joystick_button_board->GetRawButton(12))
	{
		if (joystick_button_board->GetRawButton(11))
		{
			// cout << "climb second " << endl;
			is_climbing_second = true;
		}
		else
		{
			// cout << "climb third" << endl;
			is_climbing_third = true;
		}
	}
	else
	{
		is_climbing_second = false;
		is_climbing_third = false;
	}

	// TODO: check this thing
	if (is_climbing_second || is_climbing_third)
	{
		compressor->Stop();
		climb();
	}
	else
	{

		// climber->setLiftPower(joystick_aux->GetRawAxis(1) / 2, joystick_aux->GetRawAxis(5) / 2);

		// passover->setPower(joystick_aux->GetRawAxis(1) / 2);
		// cout << "passover pot " << passover->getPosition() << endl;
		// cout << "front " << climber->getFrontPosition() << " back " << climber->getBackPosition() << endl;

		// TODO: && elevator->getPosition() > 12

		// cargo mode
		if (!joystick_button_board->GetRawButton(10))
		{
			if (joystick_button_board->GetRawButton(3))
			{
				elevator->setPosition(elevator->positions.bottom);
				passover->sendPassoverFront();
			}
			else if (joystick_button_board->GetRawButton(4))
			{
				elevator->setPosition(elevator->positions.bottom);
				passover->sendPassoverBack();
			}
			else if (joystick_button_board->GetRawButton(5))
			{
				passover->sendPassoverMiddle();
			}
			else if (joystick_button_board->GetRawButton(6))
			{
				elevator->setPosition(elevator->positions.middle + elevator->positions.cargo_offset);
				passover->sendPassoverFront();
			}
			else if (joystick_button_board->GetRawButton(7))
			{
				elevator->setPosition(elevator->positions.middle);
				passover->sendPassoverBack();
			}
			else if (joystick_button_board->GetRawButton(8))
			{
				elevator->setPosition(elevator->positions.top + 2);
				passover->sendPassoverFrontCargo();
			}
			else if (joystick_button_board->GetRawButton(9))
			{
				elevator->setPosition(elevator->positions.top);
				passover->sendPassoverBack();
			}
			else
			{
				elevator->setPower(0);
				passover->setPower(0);
			}
		}
		// hatch mode
		else
		{
			if (joystick_button_board->GetRawButton(3))
			{
				elevator->setPosition(elevator->positions.bottom);
				passover->sendPassoverFront();
			}
			else if (joystick_button_board->GetRawButton(4))
			{
				elevator->setPosition(elevator->positions.bottom);
				passover->sendPassoverBack();
			}
			else if (joystick_button_board->GetRawButton(5))
			{
				passover->sendPassoverMiddle();
			}
			else if (joystick_button_board->GetRawButton(6))
			{
				elevator->setPosition(elevator->positions.middle);
				passover->sendPassoverFront();
			}
			else if (joystick_button_board->GetRawButton(7))
			{
				elevator->setPosition(elevator->positions.middle);
				passover->sendPassoverBack();
			}
			else if (joystick_button_board->GetRawButton(8))
			{
				elevator->setPosition(elevator->positions.top);
				passover->sendPassoverFront();
			}
			else if (joystick_button_board->GetRawButton(9))
			{
				elevator->setPosition(elevator->positions.top);
				passover->sendPassoverBack();
			}
			else
			{
				elevator->setPower(0);
				passover->setPower(0);
			}
		}

		// run intake outwards so we don't pick up a cargo while at hatch pick up
		if(joystick_button_board->GetRawButton(10) && elevator->getPosition() <= elevator->positions.bottom && passover->isPolarized()) {
			intake->pushBall();
		} else {
			intake->stop();
		}

		// true is hatch
		if (joystick_button_board->GetRawButton(2) && joystick_button_board->GetRawButton(10))
		{
			intake->updateBeak(true);
		}
		else if (joystick_button_board->GetRawButton(10))
		{
			intake->updateBeak(false);
		}
		else
		{
			intake->updateBeak(true);
		}

		// CARGO MODE
		if (joystick_button_board->GetRawButton(1) && !joystick_button_board->GetRawButton(10))
		{
			is_holding_ball = true;
			intake->intakeBall();
		}
		else if (joystick_button_board->GetRawButton(2) && !joystick_button_board->GetRawButton(10))
		{
			is_holding_ball = false;
			intake->releaseBall();
		}
		else if(!joystick_button_board->GetRawButton(10) && is_holding_ball)
		{
			intake->holdBall();

		} else {
			intake->stop();
		}
	}
}

void Robot::RobotPeriodic()
{
}

void Robot::AutonomousInit()
{
	is_climbing_second = false;
	is_climbing_third = false;
	is_climbing_complete = false;
	is_back_raised = false;
	is_front_raised = false;
	is_raising_back = false;
	is_raising_front = false;

	cout << "starting auto" << endl;
	gyro->ZeroYaw();
	gyro->ResetDisplacement();
	gyro_correction->zeroPitch();
	compressor->Start();
	gyro->ZeroYaw();
	timer_climber.Start();
	drive->resetEncoders();
	climber->resetEncoders();
}

void Robot::AutonomousPeriodic()
{
	drive->setPositionTicks(62, 62);
	// cout << "left " << drive->getLeftTicks() << " right " << drive->getRightTicks() << endl;
	// update();
}

void Robot::TeleopInit()
{
	is_climbing_second = false;
	is_climbing_third = false;
	is_climbing_complete = false;
	is_back_raised = false;
	is_front_raised = false;
	is_raising_back = false;
	is_raising_front = false;
	// climb_state = CLIMB_STATES::READY;
	climber->resetEncoders();
}

void Robot::TeleopPeriodic()
{
	update();
}

void Robot::update()
{
	// cout << " low " << -abs(joystick_button_board->GetRawAxis(2)) << endl;
	// climber->setLowRider(-abs(joystick_button_board->GetRawAxis(2)));

	passover->printPotentiometer();
	// climber->printEncoders();
	// TODO: check
	if (joystick_button_board->GetRawButton(10))
	{
		// cout << " out " << endl;
		passover->setPiston(false);
	}
	else
	{
		passover->setPiston(true);
	}

	handleDriverInput();
	handleAuxiliaryInput();

	// vision_tracking->logLimelightValue("thor");
	if (is_climbing_second || is_climbing_third)
	{
		drive->TankDrive(abs(joystick_l->GetRawAxis(1)), abs(joystick_r->GetRawAxis(1)), false);
	}
	else if (setpoint_l != 0 || setpoint_r != 0)
	{
		// cout << "going to setpoint" << endl;
		drive->driveSetTicks(setpoint_l, setpoint_r);
	}
	else
	{
		if (!joystick_r->GetRawButton(driver_buttons["right"]))
		{
			drive->TankDrive(joystick_l->GetRawAxis(1) + adjust_l, joystick_r->GetRawAxis(1) + adjust_r, false);
		}

		resetDriveValues();
	}
}

void Robot::DisabledInit()
{
	cout << "I'm disabled :D" << endl;
}

void Robot::TestPeriodic()
{
}

void Robot::climb()
{

	// climber->setPositions(5000, 5000);
	// climber->setLiftPower(0.8, 0.8);

	// switch (climb_state)
	// {
	// case CLIMB_STATES::LOWERING_SECOND:
	// 	if (climber->setPositions(climber->second_position, climber->second_position))
	// 	{
	// 		climb_state = CLIMB_STATES::LOWERING_COMPLETE;
	// 		climb_level = CLIMB_STATES::LOWERING_SECOND;
	// 	}
	// 	break;
	// case CLIMB_STATES::LOWERING_THIRD:
	// 	if (climber->setPositions(climber->third_position, climber->third_position))
	// 	{
	// 		climb_state = CLIMB_STATES::LOWERING_COMPLETE;
	// 		climb_level = CLIMB_STATES::LOWERING_THIRD;
	// 	}
	// 	break;
	// case CLIMB_STATES::LOWERING_COMPLETE:
	// 	// TODO: Do a double check here with gyro or something else
	// 	cout << "done climbing" << endl;
	// 	climb_state = CLIMB_STATES::BACK_RAISING;
	// 	break;
	// case CLIMB_STATES::BACK_RAISING:
	// 	if (climb_level == CLIMB_STATES::LOWERING_SECOND && climber->setPositions(climber->second_position, 0))
	// 	{
	// 		climb_state = CLIMB_STATES::BACK_RAISED;
	// 	}

	// 	if (climb_level == CLIMB_STATES::LOWERING_THIRD && climber->setPositions(climber->third_position, 0))
	// 	{
	// 		climb_state = CLIMB_STATES::BACK_RAISED;
	// 	}
	// case CLIMB_STATES::BACK_RAISED:
	// 	// TODO: do an additional check
	// 	climb_state = CLIMB_STATES::RUN_LOWRIDER;
	// case CLIMB_STATES::RUN_LOWRIDER:
	// 	// TODO: figure something out
	// case CLIMB_STATES::FRONT_RAISING:
	// 	if (climber->setPositions(0, 0))
	// 	{
	// 		climb_state = CLIMB_STATES::FRONT_RAISED;
	// 	}
	// case CLIMB_STATES::FRONT_RAISED:
	// 	// TODO: additional check
	// 	break;
	// case CLIMB_STATES::FINISHED:
	// 	// TODO: disable the robot lol
	// }

	vector<float> values = gyro_correction->adjustClimb();

	// climb until we reach the max point, then stop lifting
	if (!is_climbing_complete && is_climbing_second)
	{
		if (climber->lowerClimberSecond(values[0], values[1]))
		{
			cout << "done climbing" << endl;
			is_climbing_complete = true;
		}
	}

	if (!is_climbing_complete && is_climbing_third)
	{
		if (climber->lowerClimberThird(values[0], values[1]))
		{
			cout << "done climbing" << endl;
			is_climbing_complete = true;
		}
	}

	// one we reach the top, sustain both sides until we specify not to with buttons
	if (is_climbing_complete)
	{

		if(!is_front_raised && !is_back_raised) {
			climber->setLowRider(-abs(joystick_button_board->GetRawAxis(2)));
		} else {
			climber->setLowRider(0);
		}

		// TODO make sure raising is done

		// is_raising_back = true;
		// is_raising_front = true;

		// the front is no longer lowered, start raising it
		if (is_raising_front)
		{
			if (!is_front_raised)
			{
				if (climber->raiseFront())
				{
					cout << "front finish raising!" << endl;
					is_front_raised = true;
					is_raising_front = false;
					climber->stopFront();
				}
			}
		}
		else if (is_front_raised)
		{
			climber->stopFront();
		}
		else
		{
			climber->sustainFront();
		}

		// the back is no longer lowered, start raising it
		if (is_raising_back)
		{
			if (!is_back_raised)
			{
				if (climber->raiseBack())
				{
					cout << "back finish raising!" << endl;
					is_back_raised = true;
					is_raising_back = false;
					climber->stopBack();
				}
			}
		}
		else if (is_back_raised)
		{
			//climber->setLowRider(-1);
			climber->stopBack();
		}
		else
		{
			climber->sustainBack();
		}

		if (joystick_button_board->GetRawButton(14))
		{
			cout << "RAISING FRONT" << endl;
			is_raising_front = true;
		}

		if (joystick_button_board->GetRawButton(13))
		{
			cout << "RAISING BACK" << endl;
			is_raising_back = true;
		}
	}
}

bool Robot::resetClimb()
{
	// todo: do this
}

void Robot::resetDriveValues()
{
	adjust_l = 0;
	adjust_r = 0;

	setpoint_l = 0.0;
	setpoint_r = 0.0;
}

void Robot::setSetpoints(float l, float r)
{
	this->setpoint_l = l;
	this->setpoint_r = r;
}

void Robot::setAdjustments(float l, float r)
{
	this->setpoint_l = l;
	this->setpoint_r = r;
}

#ifndef RUNNING_FRC_TESTS
START_ROBOT_CLASS(Robot)
#endif
